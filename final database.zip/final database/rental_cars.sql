-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: rental
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cars`
--

DROP TABLE IF EXISTS `cars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cars` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `plate_number` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `brand` varchar(255) DEFAULT NULL,
  `color` varchar(11) NOT NULL,
  `transmission` varchar(255) DEFAULT NULL,
  `capacity` int(255) DEFAULT NULL,
  `price` int(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `total_amount` varchar(255) DEFAULT '0',
  `car_status` enum('Pending','Available','Approved') DEFAULT 'Available',
  `provider` varchar(255) DEFAULT NULL,
  `date1` varchar(10) NOT NULL DEFAULT '0000-00-00',
  `date2` varchar(10) NOT NULL DEFAULT '0000-00-00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cars`
--

LOCK TABLES `cars` WRITE;
/*!40000 ALTER TABLE `cars` DISABLE KEYS */;
INSERT INTO `cars` VALUES (1,'HDN216','City Car','Vios E 2016','Toyota ','Black','Automatic',4,2500,'cover-1527875811788.png','0','Available','1','0','0'),(10,'JSN172','City Car','Corolla Altis G 2018','Toyota ','Black','Manual',4,2500,'cover-1528078111078.png','0','Available','1','0','0'),(11,'JSN263','Executive Car','Camry G 2015','Toyota ','Silver','Automatic',4,3000,'cover-1528078183103.png','0','Available','1','0000-00-00','0000-00-00'),(12,'FDB725','SUV','CR-V SE 5D 2014','Honda ','Gray','Automatic',5,3000,'cover-1528078261912.png','0','Available','1','0000-00-00','0000-00-00'),(13,'HAB374','SUV','Toyota Fortuner G 2013','Toyota ','White','Manual',7,4000,'cover-1528078369906.png','0','Available','1','0000-00-00','0000-00-00'),(14,'HDN276','SUV','Everest 2016','Ford ','White','Automatic',6,4000,'cover-1528078464884.png','0','Available','1','0000-00-00','0000-00-00'),(15,'USG273','People Carrier','County Deluxe 2015','Hyundai ','Black','Manual',24,6000,'cover-1528079940359.png','0','Available','1','0000-00-00','0000-00-00'),(20,'RFX321','Sedan','Sentra 2009','Nissan','Black','Automatic',4,2000,'sentra16.jpg','0','Available','2','0','0'),(21,'KLM612','Sedan','Lancer 2010','Mitsubishi','Red','Manual',4,2300,'lancer10.jpg','0','Available','2','0','0'),(22,'GGD754','Sedan','City 2014','Honda','Black','Automatic',4,2500,'city14.jpg','0','Available','2','0','0'),(23,'WAR554','SUV','CR-V 2008','Honda','Silver','Manual',6,3500,'crv08.jpg','0','Available','2','0','0'),(24,'GJY468','SUV','Escape 2011','Ford','Cyan','Manual',7,3800,'escape11.jpg','0','Available','2','0','0'),(25,'EIB483','Sedan','Corolla 2007','Toyota','Gray','Automatic',4,2100,'corolla07.jpg','0','Available','3','0','0'),(26,'TNO206','Sedan','Civic 2011','Honda','Black','Manual',4,2200,'civic11.jpg','0','Available','3','0','0'),(27,'DNO295','Sedan','City 2015','Honda','Blue','Automatic',4,2500,'city15.png','0','Available','3','0','0'),(28,'RVJ175','SUV','Sportage 2009','Kia','Black','Manual',7,3400,'sportage09.jpg','0','Available','3','0','0'),(29,'FFH378','SUV','Alterra 2010','Isuzu','White','Manual',6,3700,'alterra10.jpg','0','Available','3','0','0'),(30,'GHD446','Sedan','Lancer 2008','Mitsubishi','White','Automatic',4,2200,'lancer08.jpg','0','Available','4','0','0'),(31,'DFG995','Sedan','Verna 2012','Hyundai','Silver','Manual',4,2300,'verna12.jpg','0','Available','4','0','0'),(32,'KVY258','Sedan','Sentra 2016','Nissan','Black','Automatic',4,2500,'sentra16.jpg','0','Available','4','0','0'),(33,'KNY379','SUV','Fortuner 2008','Toyota','Black','Manual',7,3900,'fortuner08.jpg','0','Available','4','0','0'),(34,'ADS357','SUV','Tamaraw ','Toyota','Blue','Manual',6,2900,'tamaraw.jpg','0','Available','4','0','0'),(35,'JHJ234','Sedan','City 2006','Honda','Silver','Automatic',4,2100,'city06.jpg','0','Available','5','0','0'),(36,'TRK679','Sedan','Civic 2013','Honda','Black','Manual',4,2400,'civic13.jpg','0','Available','5','0','0'),(37,'FDJ786','Sedan','Corolla 2015','Toyota','Black','Automatic',4,2600,'corolla15.jpg','0','Available','5','0','0'),(38,'UIY654','SUV','Fortuner 2007','Toyota','Silver','Manual',7,3800,'fortuner07.jpg','0','Available','5','0','0'),(39,'CTJ587','SUV','Tamaraw ','Toyota','Blue','Manual',6,3000,'tamaraw.jpg','0','Available','5','0','0'),(40,'HDS858','Sedan','Corolla 2009','Toyota','Gray','Automatic',4,2000,'corolla09.jpg','0','Available','6','0','0'),(41,'OYY655','Sedan','Verna 2012','Hyundai','Silver','Manual',4,2200,'verna12.jpg','0','Available','6','0','0'),(42,'BQW732','Sedan','Lancer 2016','Mitsubishi','Gray','Automatic',4,2500,'lancer16.jpg','0','Available','6','0','0'),(43,'GDU645','SUV','CR-V 2009','Honda','Gray','Manual',6,3300,'crv09.jpg','0','Available','6','0','0'),(44,'JHH737','SUV','Escape 2011','Ford','Cyan','Manual',6,3500,'escape11.jpg','0','Available','6','0','0'),(45,'HFG756','Sedan','Sentra 2009','Nissan','Black','Automatic',4,2100,'sentra16.jpg','0','Available','7','0','0'),(46,'NFH668','Sedan','Lancer 2010','Mitsubishi','Red','Manual',4,2200,'lancer10.jpg','0','Available','7','0','0'),(47,'ALF734','Sedan','City 2015','Honda','Blue','Automatic',4,2400,'city15.png','0','Available','7','0','0'),(48,'JNG227','SUV','CR-V 2009','Honda','Silver','Manual',6,3400,'crv09.jpg','0','Available','7','0','0'),(49,'HLH736','SUV','Escape 2010','Ford','Black','Manual',7,3700,'escape10.jpg','0','Available','7','0','0');
/*!40000 ALTER TABLE `cars` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-19  2:34:32
