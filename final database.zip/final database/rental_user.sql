-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: rental
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id_no` int(7) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(60) NOT NULL,
  `password` varchar(120) NOT NULL,
  `firstname` char(50) NOT NULL,
  `lastname` char(120) NOT NULL,
  `contact_num` bigint(11) NOT NULL,
  `address` varchar(180) NOT NULL,
  `email` varchar(50) NOT NULL,
  `availability` enum('online','offline') NOT NULL DEFAULT 'offline',
  `status` enum('Active','Inactive') NOT NULL,
  `request` enum('Approved','Blocked','Pending') NOT NULL DEFAULT 'Pending',
  PRIMARY KEY (`id_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1242 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'camille','*84AAC12F54AB666ECFC2A83C676908C8BBC381B1','camille','tungcul',9097654567,'Balungao, Pangasinan','camille@gmail.com','offline','Active','Approved'),(6,'janmae','*AFC21A29DF8941C5DC9812806E15D2AB8EC4FA75','janmae','jorquia',9097654555,'Balungao, Pangasinan','janmae@gmail.com','offline','Active','Pending'),(7,'kenneth','rakista','kenneth','castro',9097623567,'Balungao, Pangasinan','kenneth@gmail.com','offline','Active','Approved'),(9,'yz','nhelli','yz','cacho',9876654567,'Balungao, Pangasinan','yz@gmail.com','offline','Inactive','Pending'),(11,'ralph','hatred','ralph','bince',9097654123,'Balungao, Pangasinan','ralph@gmail.com','offline','Inactive','Pending'),(12,'juraima','kagawad','juraima','baniqued',9097659967,'Balungao, Pangasinan','juraima@gmail.com','offline','Inactive','Approved'),(13,'jolli','bee','jolli','mcdo',9097654512,'Balungao, Pangasinan','jolli@gmail.com','offline','Inactive','Blocked'),(14,'mark','villanos','maki','villanos',9097654765,'Balungao, Pangasinan','maki@gmail.com','offline','Inactive','Approved'),(1234,'rey','reybalinag','john','balinag',9999999999,'baguio','johnbalinag@gmail.com','offline','Active','Approved'),(1235,'tine','tine','tine','fat',9097654098,'Balungao, Pangasinan','tine@gmail.com','offline','Active','Approved'),(1236,'kups','123','Kenneth Bryle','Castro',98217263546,'123 baguio','kenneth@gmail.com','offline','Active','Approved'),(1237,'kenneth1','123','Ken','Cas',9392604570,'253 Teachers Camp','bryle@gmail.com','offline','Active','Approved'),(1238,'superadmin','admin','jan-mae','Aquino',9271827364,'89 West Bakakeng','jan_mae@yahoo.com','offline','Active','Approved'),(1239,'test123','testtest','test','test',9123123718,'testing','test@gmail.com','offline','Active','Pending'),(1240,'dummy123','dummydummy','dum','dum',9123123718,'dummy','dummy@gmail.com','offline','Active','Pending'),(1241,'dummy123','dummydummy','dum','dum',9123123718,'dummy','dummy@gmail.com','offline','Active','Pending');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-19  2:34:31
